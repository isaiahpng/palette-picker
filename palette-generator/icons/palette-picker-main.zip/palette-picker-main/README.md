# palette-picker
A simple website that generates random color palettes
